'use client'

export default function EmployeeDrawerPage({ params }: { params: { id: string } }) {
  return null // This is handled by the employee drawer component
}