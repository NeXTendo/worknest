'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

export default function HomePage() {
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (session) {
        router.push('/dashboard')
      }
    }
    checkSession()
  }, [router, supabase])

  return (
    <div className="flex flex-col min-h-screen items-center justify-center bg-gray-50 px-4">
      {/* Logo / Hero */}
      <div className="flex flex-col items-center gap-4">
        <div className="w-24 h-24">
          <Image
            src="/worknest-icon.svg"
            alt="WorkNest Logo"
            width={96}
            height={96}
          />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 text-center">
          Welcome to WorkNest
        </h1>
        <p className="text-gray-600 text-center max-w-md">
          Your all-in-one employee management system. Manage employees, departments, payroll, attendance, and more — all in one place.
        </p>
      </div>

      {/* Call-to-action buttons */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <Button
          variant="default"
          onClick={() => router.push('/auth/login')}
          className="px-6 py-3"
        >
          Log In
        </Button>
        <Button
          variant="outline"
          onClick={() => router.push('/auth/login')}
          className="px-6 py-3"
        >
          Get Started
        </Button>
      </div>

      {/* Footer */}
      <footer className="mt-auto py-6 text-center text-sm text-gray-400">
        © 2026 WorkNest. Powered by <span className="font-semibold text-worknest-teal">TechOhns</span>
      </footer>
    </div>
  )
}
