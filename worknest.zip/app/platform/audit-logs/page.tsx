'use client'

export default function AuditLogsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Audit Logs</h1>
      <p className="text-gray-600">System audit trail - Super Admin only</p>
    </div>
  )
}