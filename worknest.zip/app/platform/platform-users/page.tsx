'use client'

export default function PlatformUsersPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Platform Users</h1>
      <p className="text-gray-600">Manage platform administrators - Super Admin only</p>
    </div>
  )
}