'use client'

export default function CompaniesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Companies</h1>
      <p className="text-gray-600">Platform companies management - Super Admin only</p>
    </div>
  )
}