'use client'

export function AppFooter() {
  return (
    <footer className="bg-slate-900 text-gray-300 py-4 px-6 text-center text-sm">
      © 2024 TechOhns. All rights reserved. WorkNest - Home to every workforce.
    </footer>
  )
}
